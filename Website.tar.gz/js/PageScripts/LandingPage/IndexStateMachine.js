﻿var currentPageState = LANDINGPAGE_STATE["Home-idle"];
$(document).ready(function ()
{
});