﻿const INVALID_RETURN = -1;
const ZIPPED_NAME = "SwagBoxContents.zip";
const KILOBYTE = 1024;
const MEGABYTE = KILOBYTE * KILOBYTE;
const MAXIMUM_UPLOAD_BYTES = 200 * MEGABYTE;
const BLOCKSIZE = 395 * KILOBYTE;
const LANDINGPAGE_STATE = 
{
    "Home-idle": 0,
    "Home-uploading": 1,
    "Home-uploaded": 3,
    "Contact-form": 4,
    "Contact-sent": 5,
    "FAQs": 6
}