﻿$(document).ready(function ()
{
    function notifyByteExceeded(contentSize)
    {
        $.notify(
        {
            icon: "glyphicon glyphicon-warning-sign",
            title: "File size exceeded 200MB: ",
            message: "The total amount of bytes uploaded (" + contentSize +
                "MB) exceeds the maximum limit."
        },
        {
            type: "warning",
            placement:
            {
                from: "top",
                align: "center"
            }
        });
    }
    function notifyCompressionFailed()
    {
        $.notify(
        {
            icon: "glyphicon glyphicon-exclamation-sign",
            title: "An error has occured",
            message: "File couldn't be compressed."
        },
        {
            type: "danger",
            placement:
            {
                from: "top",
                align: "center"
            }
        });
    }

    /* Occurs when the user uploads a file or multiple files to the server */
    $("#fileupload").on("change", function ()
    {
        const uploadedFile = document.getElementById("fileupload").files[0];
        const fileNameTokens = uploadedFile.name.split(".");
        if (uploadedFile.size > MAXIMUM_UPLOAD_BYTES)
        {
            const contentSize = (uploadedFile.size / MEGABYTE).toFixed(2);
            notifyByteExceeded( contentSize );
            return;
        }

        const jsZip = new JSZip();
        if (fileNameTokens.length > 1 && fileNameTokens[fileNameTokens.length - 1] === "zip")
        {
            zippedContentCallback( [ uploadedFile, uploadedFile ] );
            return;
        }
        jsZip.file(uploadedFile.name, uploadedFile);
        jsZip.generateAsync( { type: "blob", compression: "DEFLATE" } ).then(function (zippedContent)
        {
            const callbackContent = zippedContent.size >= uploadedFile.size ? uploadedFile : zippedContent;
             zippedContentCallback( [ uploadedFile, callbackContent ] );
        });
    });

    function zippedContentCallback( contentArray )
    {
        const uploadedContent = contentArray[0];
        const zippedContent   = contentArray[1];
        if ( zippedContent === null || zippedContent === undefined )
        {
            notifyCompressionFailed();
            return;
        }

        var reader = new FileReader();
        reader.onload = function() {
            const shaHash  = SHA512(reader.result);
            const fileSize = zippedContent.size;
            console.log(zippedContent);
            // Query the metadata server of the sha hash.
            // Query the block server for the blocks.
        }; reader.readAsText(zippedContent);
    }
});
